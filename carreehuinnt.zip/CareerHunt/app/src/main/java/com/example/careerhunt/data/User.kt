package com.example.careerhunt.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Ignore
import androidx.room.PrimaryKey
import java.time.LocalDate

@Entity(tableName = "personal")
data class Personal (
    @PrimaryKey(autoGenerate = true)
    var personalID:Int = 0,
    @ColumnInfo(name = "name")
    var name:String,
    @ColumnInfo(name = "email")
    var email:String,
    @ColumnInfo(name = "password")
    var password:String,
    @ColumnInfo(name = "graduated_from")
    var graduated_from:String,
    @ColumnInfo(name = "profile_img")
    var profile_img:String,
    @ColumnInfo(name = "phone")
    var phone:String,
    @ColumnInfo(name = "gender")
    var gender:String,
    @ColumnInfo(name = "eduLevel")
    var eduLevel:String,
    @ColumnInfo(name = "workingExp")
    var workingExp:String,

)

    //alumni community database
@Entity(tableName = "alumni_community",
    foreignKeys =
    [ForeignKey(
            entity = Personal::class,
            parentColumns = ["personalID"],
            childColumns = ["personalID"],
            onDelete = ForeignKey.CASCADE)]
)
data class Alumni_community (
    @PrimaryKey(autoGenerate = true)
    var id:Int = 0,
    @ColumnInfo(name = "title")
    var title:String,
    @ColumnInfo(name = "content")
    var content:String,
    @ColumnInfo(name = "posted_at")
    var posted_at: String,
    //foreign key
    var personalID:Int
){
        // Define a field to hold the actual parent object
        @Ignore
        lateinit var personal: Personal
}


@Entity(tableName = "alumni_community_comment",
    foreignKeys =
    [ForeignKey(
        entity = Personal::class,
        parentColumns = ["personalID"],
        childColumns = ["personalID"],
        onDelete = ForeignKey.CASCADE),
    ForeignKey(
        entity = Alumni_community::class,
        parentColumns = ["id"],
        childColumns = ["alumniCommunityID"],
        onDelete = ForeignKey.CASCADE)]
    )
data class Alumni_community_comment (
    @PrimaryKey(autoGenerate = true)
    var id:Int = 0,
    @ColumnInfo(name = "comment")
    var comment:String,
    //foreign key
    var personalID:Int,
    var alumniCommunityID:Int
)

@Entity(tableName = "alumni_community_like",
    foreignKeys =
    [ForeignKey(
        entity = Personal::class,
        parentColumns = ["personalID"],
        childColumns = ["personalID"],
        onDelete = ForeignKey.CASCADE),
        ForeignKey(
            entity = Alumni_community::class,
            parentColumns = ["id"],
            childColumns = ["alumniCommunityID"],
            onDelete = ForeignKey.CASCADE)]
)
data class Alumni_community_like (
    @PrimaryKey(autoGenerate = true)
    var id:Int = 0,
    //foreign key
    var personalID:Int,
    var alumniCommunityID:Int
)



