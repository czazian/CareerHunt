package com.example.careerhunt

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.careerhunt.data.AlumniCommunityViewModel
import com.example.careerhunt.data.Alumni_community
import com.example.careerhunt.data.Alumni_community_like
import com.example.careerhunt.dataAdapter.AlumniCommunity_adapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.SimpleDateFormat
import java.time.LocalDate

class Alumni : Fragment(), AlumniCommunity_adapter.onLikeButtonClick {

    private lateinit var alumniCommunityViewModal : AlumniCommunityViewModel

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //display fragment alumni
        val view = inflater.inflate(R.layout.fragment_alumni, container, false)

        alumniCommunityViewModal = ViewModelProvider(this).get(AlumniCommunityViewModel::class.java)

        //should be logined user id
        val alumni_like_list_personal : LiveData<List<Alumni_community_like>> = alumniCommunityViewModal.findLikeByPersonalId(1)

        val adapter = AlumniCommunity_adapter(this, alumni_like_list_personal)
        val recyclerView: RecyclerView = view.findViewById(R.id.alumni_recycle_view)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.setHasFixedSize(true)
        alumniCommunityViewModal = ViewModelProvider(this).get(AlumniCommunityViewModel::class.java)
        alumniCommunityViewModal.readAllData().observe(viewLifecycleOwner, Observer {alumniCommunityList->
            adapter.setData(alumniCommunityList)
        })

        /*
        //default list
        val alumniCommunityLists : List<AlumniCommunity> = listOf(
            AlumniCommunity("John", "TARUMT", "Title 1", "A paragraph is defined as “a group of sentences or a single sentence that forms a unit” (Lunsford and Connors 116). Length and appearance do not determine whether a section in a paper is a paragraph. For instance, in some styles of writing, particularly journalistic styles, a paragraph can be just one sentence long.", LocalDate.parse("2023-01-17")),
            AlumniCommunity("Alex", "UTAR","Title 2", "Content 2", LocalDate.parse("2023-02-17")),
            AlumniCommunity("Mark", "TARUMT", "Title 3", "A paragraph is defined as “a group of sentences or a single sentence that forms a unit” (Lunsford and Connors 116). Length and appearance do not determine whether a section in a paper is a paragraph. For instance, in some styles of writing, particularly journalistic styles, a paragraph can be just one sentence long.", LocalDate.parse("2023-03-17")),
            AlumniCommunity("Steven", "NICE", "Title 4", "Content 4", LocalDate.parse("2023-04-17")),
        )
        val recyclerView: RecyclerView = view.findViewById(R.id.alumni_recycle_view)
        //past in
        recyclerView.adapter = AlumniCommunity_adapter(alumniCommunityLists)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.setHasFixedSize(true)
        */

        //when "+" button is click
        val btnAddAlumniComm : FloatingActionButton = view.findViewById(R.id.btnAddAlumniComm)
        btnAddAlumniComm.setOnClickListener(){
            val fragment = AlumniCommunityAdd()
            val transaction = activity?.supportFragmentManager?.beginTransaction()
            transaction?.replace(R.id.frameLayout, fragment)
            transaction?.addToBackStack(null)
            transaction?.commit()
        }

        return view
    }

    //when like button is clicked, run this
    override fun onLikeButtonClick(post: Alumni_community) {
        Toast.makeText(requireContext(), post.id.toString(), Toast.LENGTH_SHORT).show()
        //create record
        alumniCommunityViewModal = ViewModelProvider(this).get(AlumniCommunityViewModel::class.java)
        //temp solution: should be personal ID of logined account of device
        val alumniCommLike = Alumni_community_like(0, 1,  post.id)
        alumniCommunityViewModal.addAlumniCommunityLike(alumniCommLike)
    }
}