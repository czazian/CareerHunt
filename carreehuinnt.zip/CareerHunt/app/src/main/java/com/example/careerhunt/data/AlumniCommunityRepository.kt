package com.example.careerhunt.data

import androidx.lifecycle.LiveData

class AlumniCommunityRepository(private val alumniCommDao : AlumniCommunityDAO) {
    val readAllData : LiveData<List<Alumni_community>> = alumniCommDao.readAllData()

    suspend fun addAlumniCommunity(alumniCommunity: Alumni_community){
        alumniCommDao.addAlumniCommunity(alumniCommunity)
    }

    fun findById(id : Int) : LiveData<Alumni_community> {
        return alumniCommDao.findById(id)
    }

    fun findCommentByPostId(id: Int) : LiveData<List<Alumni_community_comment>>{
        return alumniCommDao.findCommentByPostId(id)
    }

    suspend fun addAlumniCommunityComment(alumniCommunityComment: Alumni_community_comment){
        alumniCommDao.addAlumniCommunityComment(alumniCommunityComment)
    }

    suspend fun addAlumniCommunityLike(alumniCommunityLike: Alumni_community_like){
        alumniCommDao.addAlumniCommunityLike(alumniCommunityLike)
    }

    fun findLikeByPersonalId(id: Int) : LiveData<List<Alumni_community_like>>{
        return alumniCommDao.findLikebyPersonalId(id)
    }
}