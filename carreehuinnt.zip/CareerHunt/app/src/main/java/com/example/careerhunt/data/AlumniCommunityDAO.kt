package com.example.careerhunt.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Relation
import androidx.room.Transaction

@Dao
interface AlumniCommunityDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addAlumniCommunity(alumniCommunity : Alumni_community)

    @Query("Select * from alumni_community order by id")
    fun readAllData(): LiveData<List<Alumni_community>>

    @Query("SELECT * FROM alumni_community WHERE id = :id LIMIT 1")
    fun findById(id: Int): LiveData<Alumni_community>

    @Query("SELECT * FROM alumni_community_comment, alumni_community WHERE alumni_community_comment.alumniCommunityID = alumni_community.id AND alumni_community_comment.alumniCommunityID = :alumniCommunityID")
    fun findCommentByPostId(alumniCommunityID: Int):  LiveData<List<Alumni_community_comment>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addAlumniCommunityComment(alumniCommunityComment: Alumni_community_comment)

    //still not able to get object
    //data class Alumni_community(
    //    @Embedded val alumni_community: Alumni_community,
    //    @Relation(
    //        parentColumn = "personalID",
    //        entityColumn = "personalID"
    //    )
     //   val personal: Personal
   // )

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addAlumniCommunityLike(alumniCommunityLike: Alumni_community_like)

    @Query("Select * from alumni_community_like WHERE personalID = :id")
    fun findLikebyPersonalId(id : Int): LiveData<List<Alumni_community_like>>
}