package com.example.careerhunt.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlumniCommunityViewModel(application: Application) : AndroidViewModel(application) {
    private val readAllData: LiveData<List<Alumni_community>>
    private val repository : AlumniCommunityRepository
    init {
        val alumniCommunityDAO = CareerHuntDatabase.getDatabse(application).alumniCommDao()
        repository = AlumniCommunityRepository(alumniCommunityDAO)
        readAllData = repository.readAllData

    }
    fun addAlumniCommunity(alumniCommunity: Alumni_community){
        viewModelScope.launch (Dispatchers.IO ){
            repository.addAlumniCommunity(alumniCommunity)
        }
    }

    fun readAllData() : LiveData<List<Alumni_community>> {
        return readAllData
    }

    fun findById(id : Int) : LiveData<Alumni_community> {
        return repository.findById(id)
    }

    fun findCommentbyPostId(id : Int) : LiveData<List<Alumni_community_comment>>{
        return repository.findCommentByPostId(id)
    }

    fun addAlumniCommunityComment(alumniCommunityComment: Alumni_community_comment){
        viewModelScope.launch (Dispatchers.IO ){
            repository.addAlumniCommunityComment(alumniCommunityComment)
        }
    }

    fun addAlumniCommunityLike(alumniCommunityLike: Alumni_community_like){
        viewModelScope.launch (Dispatchers.IO ){
            repository.addAlumniCommunityLike(alumniCommunityLike)
        }
    }

    fun findLikeByPersonalId(id : Int) : LiveData<List<Alumni_community_like>>{
        return repository.findLikeByPersonalId(id)
    }
}